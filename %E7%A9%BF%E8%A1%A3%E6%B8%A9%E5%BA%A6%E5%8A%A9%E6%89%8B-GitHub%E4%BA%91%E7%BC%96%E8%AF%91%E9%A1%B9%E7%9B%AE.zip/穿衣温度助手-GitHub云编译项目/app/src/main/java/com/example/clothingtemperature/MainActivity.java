package com.example.clothingtemperature;

import android.app.Activity;
import android.os.Bundle;
import android.graphics.Typeface;
import android.view.Gravity;
import android.widget.*;
import java.util.Locale;

public class MainActivity extends Activity {
    private EditText input;
    private TextView result;

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        LinearLayout page = new LinearLayout(this);
        page.setOrientation(LinearLayout.VERTICAL);
        page.setPadding(dp(24), dp(36), dp(24), dp(24));
        page.setGravity(Gravity.TOP);
        page.setBackgroundColor(0xFFF6F7F9);

        TextView title = new TextView(this);
        title.setText("穿衣温度助手");
        title.setTextSize(26);
        title.setTypeface(null, Typeface.BOLD);
        page.addView(title);

        TextView tip = new TextView(this);
        tip.setText("输入当前气温（℃），查询对应穿着");
        tip.setTextSize(16);
        LinearLayout.LayoutParams tp = params(); tp.topMargin = dp(12);
        page.addView(tip, tp);

        input = new EditText(this);
        input.setSingleLine(true);
        input.setTextSize(20);
        input.setHint("例如：15 或 18.5");
        input.setInputType(8194);
        LinearLayout.LayoutParams ip = params(); ip.topMargin = dp(20);
        page.addView(input, ip);

        Button button = new Button(this);
        button.setText("查询穿着");
        LinearLayout.LayoutParams bp = params(); bp.topMargin = dp(12);
        page.addView(button, bp);

        result = new TextView(this);
        result.setTextSize(18);
        result.setTextColor(0xFF17202A);
        result.setPadding(dp(16), dp(18), dp(16), dp(18));
        result.setBackgroundColor(0xFFFFFFFF);
        LinearLayout.LayoutParams rp = params(); rp.topMargin = dp(20);
        page.addView(result, rp);

        button.setOnClickListener(v -> query());
        setContentView(page);
    }

    private void query() {
        String s = input.getText().toString().trim();
        if (s.isEmpty()) { result.setText("请先输入温度。"); return; }
        try {
            double t = Double.parseDouble(s);
            result.setText(String.format(Locale.CHINA, "当前温度：%s℃\n\n穿着建议：\n%s", s, clothes(t)));
        } catch (NumberFormatException e) {
            result.setText("请输入有效数字，例如 15 或 18.5。");
        }
    }

    private String clothes(double t) {
        if (t < 6) return "目前没有设置低于 6℃ 的穿着规则。";
        if (t < 8) return "保暖内衣2、秋裤、秋褂、厚裤子、手套、保暖内裤2、袜子、保暖鞋、头罩、加热鞋垫";
        if (t < 10) return "保暖内衣2、秋裤、秋褂、厚裤子、手套、保暖内裤、袜子、保暖鞋、头罩、加热鞋垫";
        if (t < 12) return "保暖内衣2、秋裤、秋褂、厚裤子、保暖内裤、袜子、保暖鞋、头罩";
        if (t < 14) return "保暖内衣2、秋裤、秋褂、厚裤子、保暖内裤、袜子、保暖鞋";
        if (t < 16) return "保暖内衣2、秋裤、秋褂、厚裤子、保暖内裤、袜子、透气鞋";
        if (t < 18) return "保暖内衣、秋裤、秋褂、厚裤子、保暖内裤、袜子、透气鞋";
        if (t < 20) return "保暖内衣、厚裤子、秋裤、秋褂、袜子、透气鞋";
        if (t < 22) return "保暖内衣、薄裤子、秋裤、秋褂、透气鞋";
        if (t < 24) return "秋裤、秋褂、薄裤子、透气鞋";
        if (t <= 26) return "秋褂、薄裤子、透气鞋";
        return "无秋裤秋褂";
    }

    private LinearLayout.LayoutParams params() {
        return new LinearLayout.LayoutParams(-1, -2);
    }
    private int dp(int n) {
        return (int)(n * getResources().getDisplayMetrics().density + 0.5f);
    }
}
